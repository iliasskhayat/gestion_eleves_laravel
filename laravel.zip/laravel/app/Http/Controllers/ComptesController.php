<?php

namespace App\Http\Controllers;

use App\Models\comptes;
use Illuminate\Http\Request;
use Symfony\Contracts\Service\Attribute\Required;

class ComptesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
       return view('login');
    }
    
    public function connexion()
    {
        request()->validate([
        'LOGIN'=>['required','login'],
         'passwd'=>['required']
        ]);
        // auth()->attempt(
        //     [
        //         'LOGIN'=>request('login'),
        //         'password'=>request('pass'),
        //     ]
        //     );
      return view('eleves.formCrier');
    }

    
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\comptes  $comptes
     * @return \Illuminate\Http\Response
     */
    public function show(comptes $comptes)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\comptes  $comptes
     * @return \Illuminate\Http\Response
     */
    public function edit(comptes $comptes)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\comptes  $comptes
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, comptes $comptes)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\comptes  $comptes
     * @return \Illuminate\Http\Response
     */
    public function destroy(comptes $comptes)
    {
        //
    }
}
