<?php

namespace App\Http\Controllers;

use App\Models\eleves;
use Illuminate\Http\Request;

class elevesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $etd=eleves::all();
        return view('eleves.info',['studs'=>$etd]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {

        return view('eleves.formCrier');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store( Request  $request)
    {
        $elev=new eleves();
        $elev->CNE=$request->cne;
        $elev->NOM=$request->nom;
        $elev->PRENOM=$request->prenom;
        $elev->VILLE=$request->ville;
        $elev->EMAIL=$request->email;
        $elev->PHOTO=$request->photo;
        $elev->save();
        return Redirect('/eleves'); 
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
       
       return view('eleves.edit',['stud'=>eleves::find($id)]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $elev=eleves::find($id);      
          $elev->CNE=$request->cne;
        $elev->NOM=$request->nom;
        $elev->PRENOM=$request->prenom;
        $elev->VILLE=$request->ville;
        $elev->EMAIL=$request->email;
        $elev->PHOTO=$request->photo;
        $elev->save();
        return Redirect('/eleves'); 
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $etud=eleves::find($id);
        $etud->delete();
        return redirect('/eleves');
    }
}
