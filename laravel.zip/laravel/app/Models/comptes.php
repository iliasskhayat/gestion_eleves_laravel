<?php

namespace App\Models;

use Illuminate\Contracts\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Auth\Authenticatable as basic;
class comptes extends Model;
{
     use basic;
    protected $fillable=['LOGIN','PASSWD'];
}
