<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\comptes;

class compteSeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
      comptes::create([
          'login'=>'iliass',
          'passwd'=>'i am iliass'
      ]);
    }
}
