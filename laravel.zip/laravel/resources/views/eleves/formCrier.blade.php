<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">   
    <link rel="stylesheet" href="/css/styleCrier.css">
     <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
   
</head>
<body>
   <div id="uul"> 
<ul  class="nav nav-tabs" > 
    <li class="active" ><a href="/eleves/create"> ajouter un etudiant </a></li>
    <li class="nav-item" ><a href="/eleves">home</a> </li>
</ul>
</div>
<center>
    
    <h2>ajouter un etudiant</h2>

    <form action="/eleves" method="POST">
        @csrf
        <table >


       <div class="form-group">
            <tr>
                <th class="ecrit">CNE:</th>
                <td><input type="text" name="cne" class="form-control"></td>
            </tr>
       
            <tr>
                <th class="ecrit">NOM:</th>
                <td><input type="text" name="nom" class="form-control" ></td>
            </tr>
            <tr>
                <th class="ecrit">PRENOM:</th>
                <td><input type="text" name="prenom" class="form-control" ></td>
            </tr>
        
            <tr>
                <th class="ecrit" >VILLE:</th>
                <td><input type="text" name="ville" class="form-control" ></td>
            </tr>
            <tr>
                <th class="ecrit" >EMAIL:</th>
                <td><input type="text" name="email" class="form-control"></td>
            </tr>
         </div>
         <tr>
             <th class="ecrit"  >PHOTO:</th>
             <td><input type="file" name="photo" class="form-control"></td>
         </tr>
            <tr>
                <td class="buttn"><button type="submit" class="btn btn-primary" id="btnzid" >ajouter</button></td>
                <td class="buttn"><button type="reset" class="btn btn-light"  id="btnzid2">annuler</button></td>
            </tr>
        </table>
    </form>
</center>
</body>
</html>