<!-- <center>
    <h1>data sur un eleve </h1>
   <ul>
       <li>cne: {{$student['CNE']}}</li>
       <li>nom:{{$student['NOM']}}</li>
       <li>prenom:{{$student['PRENOM']}}</li>
       <li>ville:{{$student['VILLE']}}</li>
       <li>email:{{$student['EMAIL']}}</li>
   </ul>
   
</center> -->
