<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>   
 <link rel="stylesheet" href="/css/login.css">  

    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>

body
{
    padding-top: 100px;
    
}
</style>
<body>
<center>
<!-- <form action="/connex" method="post"  class="w3-container">
@csrf

<table >
    <tr>
        <th>LOGIN:</th>
        <td><input  class="w3-input" type="text" name="login"></td>
    </tr>
    <tr >
        <th>password</th>
        <td><input type="text" name="pass" class="w3-input" ></td>
    </tr>
    <tr>
        <td><button type="submit">login</button></td>
        <td><button type="reset">annuler</button></td>
    </tr>
</table>

</form>  -->
<form action="#" method="post">

<div class="wrapper fadeInDown">
  <div id="formContent">
    <!-- Tabs Titles -->

    <!-- Icon -->
    <div class="fadeIn first">
      
      <h1>login</h1>
    </div>

    <!-- Login Form -->
    <form>
      <input type="text" id="login" class="fadeIn second" name="login" placeholder="username">
      <input type="text" id="password" class="fadeIn third" name="pass" placeholder="password">
      <input type="submit" class="fadeIn fourth" value="Log In">
    </form>

   
    

  </div>
</div>
</form>
</center>
</body>
</html>