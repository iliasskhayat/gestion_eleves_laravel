<?php

use App\Http\Controllers\ComptesController;
use App\Http\Controllers\ElevesController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });
//Route::get('/',function(){ return view('comptes.login');});
Route::resource('/eleves',ElevesController::class);
Route::resource('/comptes',ComptesController::class);
// Route::get('/',function(){
//     return view('login');
// });
Route::GET('/',[ComptesController::class,'index']);
Route::get('/connex',[ComptesController::class,'connexion']);

// Route::get('/eleves',[ElevesController::class,'index']);
// Route::post('/eleves',[ElevesController::class,'store']);
// Route::get('/eleves/create',[ElevesController::class,'create']);
//Route::post('/etudints/store',[ElevesController::class,'store'])->name('store');
// Route::get('/etudiants/edit',function(){return view('eleves.edit');});


