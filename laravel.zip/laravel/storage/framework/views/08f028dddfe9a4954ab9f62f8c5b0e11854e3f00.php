<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    

<center>

<form action="comptes/<?php echo e(); ?>" method="POST">
<?php echo csrf_field(); ?>
<?php echo method_field('HEAD'); ?>
<table>
    <tr>
        <th>LOGIN:</th>
        <td><input type="text" name="login"></td>
    </tr>
    <tr>
        <th>password</th>
        <td><input type="text" name="login"></td>
    </tr>
    <tr>
        <td><button type="submit">login</button></td>
        <td><button type="reset">annuler</button></td>
    </tr>
</table>

</form>
</center>
</body>
</html><?php /**PATH C:\xampp\htdocs\gestion_eleves\resources\views/eleves/login.blade.php ENDPATH**/ ?>