<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">   
    <link rel="stylesheet" href="/css/styleInfo.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
 
</head>
<body>
    
<div id="ull">
<ul  class="nav nav-tabs" role="tablist"> 
    <li class="nav-item" ><a href="/eleves/create"> ajouter un etudiant</a></li>
    <li class="active" ><a href="/eleves">home</a> </li>
    <li  class="next"><a href="/">Deconnexion</a></li>
</ul>
</div>
<center>
     <h1>la liste des étudiants</h1>
    <!-- <table border="1" class="table table-striped"> -->
        <table id="customers">
        <tr>
            <th class="case" scope="col" >CNE</th>
            <th  class="case" scope="col" >NOM</th>
            <th  class="case" scope="col" >PRENOM</th>
            <th  class="case" scope="col" >VILLE</th>
            <th  class="case" scope="col">EMAIL</th>
            <th  class="case" scope="col">PHOTO</th>

            <th    scope="col" >OPTIONS</th>
            <!-- <th colspan="3"><a href="/eleves/create"> ajouter</a></th> -->
        </tr>
        <?php foreach($studs as $elv):?>
        <tr>
            <td><?php echo $elv['CNE']  ;?></td>
            <td> <?php echo $elv['NOM']  ;?></td>
            <td><?php echo $elv['PRENOM']  ;?></td>
            <td><?php echo $elv['VILLE']  ;?></td>
            <td><?php echo $elv['EMAIL']  ;?></td> 
            <td>  <img src ="<?php echo "/IMG/" . $elv['PHOTO'];?>"/> </td>

            <td> <a href="/eleves/<?php echo e($elv['id']); ?>/edit"><button class="btn btn-outline-info">edit</button>  </a>
            <!-- <td><a href="/eleves/<?php echo e($elv['id']); ?>"><button>show</button> </a></td> -->
      
            <form action="/eleves/<?php echo e($elv['id']); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-primary" >delete</button>
            </form>
        </td>
        </tr>
       <?php endforeach;?> 

         <!-- <tr>
            <th colspan="7"> <a href="/eleves/create"> <button>ajouter un eleve</button> </a></th>
        </tr> -->
    </table>
</center>
</body>
</html><?php /**PATH C:\xampp\htdocs\gestion_eleves\resources\views/eleves/info.blade.php ENDPATH**/ ?>