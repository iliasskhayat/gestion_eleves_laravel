<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">   
    <link rel="stylesheet" href="/css/styleEdit.css">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
   
</head>
<body>
    
<ul  class="nav nav-tabs" role="tablist"> 
    <li class="nav-item" ><a href="/eleves/create"> ajouter un eleve </a></li>
    <li class="nav-item" ><a href="/eleves">home</a> </li>
</ul>

<center>
    <h2>modifier les information de l'etudiant identifié par  CIN=<?php echo $stud['CNE']; ?></h2>
    <form action="/eleves/<?php echo e($stud['id']); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <table>
            <tr>
                <th>CNE:</th>
                <td><input type="text" name="cne" value="<?php echo e($stud['CNE']); ?>" class="form-control" ></td>
            </tr>
            <tr>
                <th>NOM:</th>
                <td><input type="text" name="nom"  value="<?php echo e($stud['NOM']); ?>" class="form-control" ></td>
            </tr>
            <tr>
                <th>PRENOM:</th>
                <td><input type="text" name="prenom" value="<?php echo e($stud['PRENOM']); ?>" class="form-control" ></td>
            </tr>
            <tr>
                <th>VILLE:</th>
                <td><input type="text" name="ville"  value="<?php echo e($stud['VILLE']); ?>" class="form-control" ></td>
            </tr>
          
            <tr>
                <th>EMAIL:</th>
                <td><input type="text" name="email"  value="<?php echo e($stud['EMAIL']); ?>" class="form-control" ></td>
            </tr> 
             <tr>
             <th>PHOTO:</th>
             <td><input type="file" name="photo" class="form-control"></td>
         </tr>
            <tr>
                <td><button type="submit" class="btn btn-primary" id="btnzid">modifier</button></td>
                <td><button type="reset" class="btn btn-light" id="btnzid" >annuler</button></td>
            </tr>
        </table>
    </form>
</center>
</body>
</html><?php /**PATH C:\xampp\htdocs\gestion_eleves\resources\views/eleves/edit.blade.php ENDPATH**/ ?>