<center>
    <h1>data sur un eleve </h1>
   <ul>
       <li>cne: <?php echo e($student['CNE']); ?></li>
       <li>nom:<?php echo e($student['NOM']); ?></li>
       <li>prenom:<?php echo e($student['PRENOM']); ?></li>
       <li>ville:<?php echo e($student['VILLE']); ?></li>
       <li>email:<?php echo e($student['EMAIL']); ?></li>
   </ul>
   
</center>
<?php /**PATH C:\xampp\htdocs\gestion_eleves\resources\views/eleves/show.blade.php ENDPATH**/ ?>